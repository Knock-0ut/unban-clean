# Monotone-HWID-Spoofer
Custom Created Hardware ID Spoofer to Bypass Hardware or IP Bans
<br>
## How To Use
* git clone https://github.com/5R33CH4/Monotone-HWID-Spoofer
* cd Monotone-HWID-Spoofer
* open monotone.exe
* give admin privilages
* click 'Unban'
* Enjoy

